!(function() {
	wap2app.init({
		globalOptions: {
			matchHostnames: "", //匹配页面的location.hostname,类型：String | Array(String) | RegExp | Function
			navigationbar: {
				backgroundColor: '#f7f7f7',//导航栏背景色
				titleColor: '#000000',//标题颜色
				titleSize: '17px',//标题字体大小
				borderColor:'#cccccc',//导航栏下边框颜色
				icons:{
					back:true,//左上角返回箭头
					home:false//右上角'首页'图标，默认不绘制
				}
			}
		},
		webviews: {
			'launch': {
				url: '',//首页地址
				matchPathnames:function(pathname,location){
					return location.href==='';
				}
			}
		}
	});
})();